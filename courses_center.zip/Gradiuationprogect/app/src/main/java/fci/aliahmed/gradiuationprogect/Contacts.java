package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class Contacts extends AppCompatActivity
{
    //definition of the variable used in this screen
    TextView address,phone1,phone2,phone3;
    ImageButton cal1,cal2,cal3,facebook,gamil;


    @Override
    // the main function
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        //setting the address text view
        address=(TextView)findViewById(R.id.adress);
        address.setText("28 Military Engineers Tower, " +
                "Next to Sadat Academy " +
                "and Smart Computer mall, Maadi" +
                ", Cairo, Egypt.");


        //setting phone 1
        phone1=(TextView)findViewById(R.id.phone1);
        phone1.setText("01140325255");

        //setting phone 2
        phone2=(TextView)findViewById(R.id.phone2);
        phone2.setText("01017743315");

        //setting phone 3
        phone3=(TextView)findViewById(R.id.phone3);
        phone3.setText("01200302842");

        //image button used to make a call for one fo the mobile phones
        cal1=(ImageButton)findViewById(R.id.call1);
        cal2=(ImageButton)findViewById(R.id.call2);
        cal3=(ImageButton)findViewById(R.id.call3);

        //image button to go to the center account on facebook or googl+
        facebook=(ImageButton)findViewById(R.id.face);
        gamil=(ImageButton)findViewById(R.id.gmail);


        //function that make intent to get the phone call board
        cal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent();
                in.setAction(Intent.ACTION_CALL);
                Uri uri=Uri.parse("tel:" + phone1.getText().toString().trim());
                in.setData(uri);
                startActivity(in);
            }
        });
        //function that make intent to get the phone call board
        cal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent();
                in.setAction(Intent.ACTION_CALL);
                Uri uri=Uri.parse("tel:" + phone2.getText().toString().trim());
                in.setData(uri);
                startActivity(in);
            }
        });
        //function that make intent to get the phone call board
        cal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent();
                in.setAction(Intent.ACTION_CALL);
                Uri uri=Uri.parse("tel:" + phone3.getText().toString().trim());
                in.setData(uri);
                startActivity(in);
            }
        });

        //function the make intent to go to the url of facebook account of the center
        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent();
                in.setAction(Intent.ACTION_VIEW);
                Uri uri=Uri.parse("https://www.facebook.com/ITSharks");
                in.setData(uri);
                startActivity(in);
            }
        });

        //function the make intent to go to the url of google+ account of the center
        gamil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent();
                in.setAction(Intent.ACTION_VIEW);
                Uri uri=Uri.parse("https://plus.google.com/+ITSharksTrainingCenterCairo");
                in.setData(uri);
                startActivity(in);
            }
        });

    }

    //function that get  item from the option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_contacts,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //to get the item id and save it to go to the item later
        int id =item.getItemId();

        if(id==R.id.cources)
        {
            Intent intent=new Intent(Contacts.this,cources.class);
            startActivity(intent);
            return  true;
        }

        if(id==R.id.instructor)
        {
            Intent in =new Intent(Contacts.this,instructors.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.emplyee)
        {
            Intent in =new Intent(Contacts.this,employees.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.reviews)
        {
            Intent in =new Intent(Contacts.this,Reaviews.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.location)
        {
            Intent in=new Intent(Intent.ACTION_VIEW);
            Uri uri=Uri.parse("geo:0,0?q=it sharks");
            in.setData(uri);
            startActivity(in);
            return  true;
        }

        if(id==R.id.contact)
        {
            Intent in =new Intent(Contacts.this,Contacts.class);
            startActivity(in);
            return  true;
        }
        return super.onOptionsItemSelected(item);
    }
}
