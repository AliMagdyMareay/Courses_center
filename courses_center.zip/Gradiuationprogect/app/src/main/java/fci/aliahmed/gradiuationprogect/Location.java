package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

//the main function
public class Location extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_location,menu);
        return true;
    }
    //function that get  item from the option menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //to get the item id and save it to go to the item later
        int id =item.getItemId();

        if(id==R.id.cources)
        {
            Intent intent=new Intent(Location.this,cources.class);
            startActivity(intent);
            return  true;
        }

        if(id==R.id.instructor)
        {
            Intent in =new Intent(Location.this,instructors.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.emplyee)
        {
            Intent in =new Intent(Location.this,employees.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.reviews)
        {
            Intent in =new Intent(Location.this,Reaviews.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.location)
        {
            Intent in=new Intent(Intent.ACTION_VIEW);
            Uri uri=Uri.parse("geo:0,0?q=it sharks");
            in.setData(uri);
            startActivity(in);
            return  true;
        }

        if(id==R.id.contact)
        {
            Intent in = new Intent(Location.this, Contacts.class);
            startActivity(in);
            return  true;
        }
        return super.onOptionsItemSelected(item);
    }
}
