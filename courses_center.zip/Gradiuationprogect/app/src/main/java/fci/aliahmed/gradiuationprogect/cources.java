package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class cources extends AppCompatActivity
{
    //definition of the variable used in this screen
    ListView coursesListView;
    int courseImages;
    courses_adapter adapter;

    //object from object class
    ArrayList <object> course_data=new ArrayList<>();
    // define the variables used in object class constructor
    String coursesNames,coursesContent,coursesHours,coursesWeeks;

    // the main function
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cources);

        //casting the list view with the design
        coursesListView=(ListView)findViewById(R.id.courses_list);

        //object from sql database
        final sql_database database=new sql_database(this);
        final SQLiteDatabase liteDatabase=database.getReadableDatabase();
        Cursor cursor=liteDatabase.query(sql_database.table_courses,null,null,null,null,null,null);

        if (cursor.moveToFirst())
        {

            do
            {
                //getting information form database and save it
                coursesNames=cursor.getString(cursor.getColumnIndex(database.course_name));
                courseImages=cursor.getInt(cursor.getColumnIndex(database.course_image));
                coursesContent=cursor.getString(cursor.getColumnIndex(database.course_content));
                coursesHours=cursor.getString(cursor.getColumnIndex(database.course_hours));
                coursesWeeks=cursor.getString(cursor.getColumnIndex(database.course_weeks));
                course_data.add(new object(courseImages,coursesNames,coursesContent,coursesHours,coursesWeeks));
            }
            while (cursor.moveToNext());
        }
        //setting the list view with data
        adapter=new courses_adapter(course_data,cources.this);
        coursesListView.setAdapter(adapter);


        //function that determine which item is selected
        coursesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                int image=course_data.get(position).get_image();
                String name=course_data.get(position).get_name();
                String content=course_data.get(position).get_content();
                String hours=course_data.get(position).get_hours();
                String weeks=course_data.get(position).get_weeks();

                liteDatabase.rawQuery("Select " + database.course_image + " from " + database.table_courses + " Where " + database.course_image + " = " + image, null);

                //intent to move from courses activity to selected course activity with its data
                Intent in =new Intent(cources.this,course_selected.class);
                in.putExtra("name",name);
                in.putExtra("image", image);
                in.putExtra("content", content);
                in.putExtra("hours", hours);
                in.putExtra("weeks", weeks);
                startActivity(in);

            }
        });
    }
    //function that get  item from the option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_cources,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //to get the item id and save it to go to the item later
        int id=item.getItemId();

        if(id==R.id.cources)
        {
            Intent intent=new Intent(cources.this,cources.class);
            startActivity(intent);
            return  true;
        }

        if(id==R.id.instructor)
        {
            Intent in =new Intent(cources.this,instructors.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.emplyee)
        {
            Intent in =new Intent(cources.this,employees.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.reviews)
        {
            Intent in =new Intent(cources.this,Reaviews.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.location)
        {
            Intent in=new Intent(Intent.ACTION_VIEW);
            Uri uri=Uri.parse("geo:0,0?q=it sharks");
            in.setData(uri);
            startActivity(in);
            return  true;
        }

        if(id==R.id.contact)
        {
            Intent in =new Intent(cources.this,Contacts.class);
            startActivity(in);
            return  true;
        }

        return super.onOptionsItemSelected(item);
    }
}
