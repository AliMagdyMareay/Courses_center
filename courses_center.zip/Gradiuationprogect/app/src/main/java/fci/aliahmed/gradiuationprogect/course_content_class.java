package fci.aliahmed.gradiuationprogect;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class course_content_class extends Fragment
{
    //definition of the variable used in this screen
    TextView content;

    @Nullable
    @Override
    //function to call fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.course_content,null);

        Bundle bundle=getActivity().getIntent().getExtras();
        String courseContent=bundle.getString("content");

        //setting the content text view
        content=(TextView) view.findViewById(R.id.course_content);
        content.setText(courseContent);

        return view;
    }
}
