package fci.aliahmed.gradiuationprogect;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class course_info_class extends Fragment
{
    //definition of the variable used in this screen
    TextView courseName,courseHoures,courseWeeks;
    @Nullable
    @Override

    //function to call fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.course_info, null);

        //bundle is used to receive data from other class
        Bundle bundle=getActivity().getIntent().getExtras();

        String name=bundle.getString("name");
        String hours=bundle.getString("hours");
        String weeks=bundle.getString("weeks");


        //casting the text views
        courseName=(TextView) view.findViewById(R.id.course_info_name);
        courseHoures=(TextView)view.findViewById(R.id.course_info_hours);
        courseWeeks=(TextView)view.findViewById(R.id.course_info_weeks);


        //setting course information
        courseName.setText(name);
        courseHoures.setText(hours);
        courseWeeks.setText(weeks);


        return  view;
    }
}
