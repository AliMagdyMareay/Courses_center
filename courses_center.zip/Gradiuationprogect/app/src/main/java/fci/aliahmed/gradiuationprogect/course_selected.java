package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class course_selected extends AppCompatActivity
{
    //definition of the variable used in this screen
    ImageView coursePhoto;
    Button courseInformation,courseContent;

    //the main function
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_selected);

        //object from sql database class
        sql_database database=new sql_database(this);
        SQLiteDatabase liteDatabase=database.getReadableDatabase();
        Cursor cursor=liteDatabase.query(sql_database.table_courses,null,null,null,null,null,null);

        final FragmentManager fmanger=getSupportFragmentManager();
       //casting for the views
        courseInformation=(Button)findViewById(R.id.course_info);
        courseContent=(Button)findViewById(R.id.content);
        coursePhoto=(ImageView)findViewById(R.id.cours_photo);

        //setting the image view
        Bundle bundle=getIntent().getExtras();
        int c_image=bundle.getInt("image");
        coursePhoto.setImageResource(c_image);

        //function to set the button to make an action
        courseInformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = fmanger.beginTransaction();
                Fragment fragment = new course_info_class();
                transaction.replace(R.id.fram2, fragment);
                transaction.commit();
            }
        });
        courseContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = fmanger.beginTransaction();
                Fragment fragment = new course_content_class();
                transaction.replace(R.id.fram2, fragment);
                transaction.commit();
            }
        });
    }

    //function that get  item from the option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_selected_course,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //to get the item id and save it to go to the item later
        int id=item.getItemId();

        if(id==R.id.cources)
        {
            Intent intent=new Intent(course_selected.this,cources.class);
            startActivity(intent);
            return  true;
        }

        if(id==R.id.instructor)
        {
            Intent in =new Intent(course_selected.this,instructors.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.emplyee)
        {
            Intent in =new Intent(course_selected.this,employees.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.reviews)
        {
            Intent in =new Intent(course_selected.this,Reaviews.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.location)
        {
            Intent in=new Intent(Intent.ACTION_VIEW);
            Uri uri=Uri.parse("geo:0,0?q=it sharks");
            in.setData(uri);
            startActivity(in);
            return  true;
        }

        if(id==R.id.contact)
        {
            Intent in =new Intent(course_selected.this,Contacts.class);
            startActivity(in);
            return  true;
        }

        return super.onOptionsItemSelected(item);
    }

}
