package fci.aliahmed.gradiuationprogect;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

//adapter for courses list view
public class courses_adapter extends BaseAdapter
{
    //definition of variables
    ArrayList <object> data=new ArrayList<>();
    Activity activity;

    //constrictor
    public courses_adapter(ArrayList <object> data,Activity activity)
    {
        this.data=data;
        this.activity=activity;
    }

    //function to return the number of elements
    @Override
    public int getCount()
    {
        return data.size();
    }

    //function to return the item position
    @Override
    public Object getItem(int position)
    {
        return null;
    }

    //function to return the id of the item
    @Override
    public long getItemId(int position)
    {
        return 0;
    }

    //function to connect the list view desgin class and code class
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater=activity.getLayoutInflater();
        View view =inflater.inflate(R.layout.list_of_cources, null);
        ImageView courseImage=(ImageView)view.findViewById(R.id.cours_image);
        TextView courseName=(TextView)view.findViewById(R.id.cours_name);
        courseImage.setImageResource(data.get(position).get_image());
        courseName.setText(data.get(position).get_name());
        return view;
    }
}
