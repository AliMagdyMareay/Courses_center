package fci.aliahmed.gradiuationprogect;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

//adapter for employee list view
public class employee_adapter extends BaseAdapter
{
    //definition of variables
    int []employeeImage;
    String []employeeNname;
    String []employeePosition;
    Activity activity;

    //constructor
    public employee_adapter (int [] image,String[]employee_name,String [] employee_position,Activity activity)
    {
        this.employeeImage=image;
        this.employeeNname=employee_name;
        this.employeePosition=employee_position;
        this.activity=activity;
    }

    //function to return the number of elements
    @Override
    public int getCount() {return employeeNname.length;}

    //function to return the item position
    @Override
    public Object getItem(int position) {return null;}

    //function to return the id of the item
    @Override
    public long getItemId(int position) {return 0;}

    //function to connect the list view desgin class and code class
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater=activity.getLayoutInflater();
        View view=inflater.inflate(R.layout.list_of_employee, null);
        ImageView emp_image=(ImageView)view.findViewById(R.id.emp_image);
        TextView emp_name=(TextView)view.findViewById(R.id.emp_name);
        TextView emp_position=(TextView)view.findViewById(R.id.emp_position);
        emp_image.setImageResource(employeeImage[position]);
        emp_name.setText(employeeNname[position]);
        emp_position.setText(employeePosition[position]);
        return  view;
    }
}
