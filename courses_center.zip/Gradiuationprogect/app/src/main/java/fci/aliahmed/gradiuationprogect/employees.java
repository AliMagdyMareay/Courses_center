package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

public class employees extends AppCompatActivity
{
    //definition of the variable used in this screen
    ListView employeeListView;

    //setting the data of the employee
    int []employeeImages=new int[]{R.drawable.mohamed_elsafty,R.drawable.eslam_yousef,R.drawable.sabah,R.drawable.saraah,R.drawable.eman};
    String [] employeeNames=new String[]{"MOHAMED ELSAFTY","ESLAM YOUSEF","SABAH A.ELGLIL","SARAH SAYED","EMAN AHMED"};
    String [] employeePosition=new String[]{"Director","Asistant Dirictor","Reception","Social Media","Cafetaria"};

    employee_adapter adapter;

    //the main function
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employees);

        //setting the data in list view
        employeeListView=(ListView)findViewById(R.id.employee_list);
        adapter=new employee_adapter(employeeImages,employeeNames,employeePosition,employees.this);
        employeeListView.setAdapter(adapter);
    }

    //function that get  item from the option menu
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.employees,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        //to get the item id and save it to go to the item later
        int id =item.getItemId();

        if(id==R.id.cources)
        {
            Intent intent=new Intent(employees.this,cources.class);
            startActivity(intent);
            return  true;
        }

        if(id==R.id.instructor)
        {
            Intent in =new Intent(employees.this,instructors.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.emplyee)
        {
            Intent in =new Intent(employees.this,employees.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.reviews)
        {
            Intent in =new Intent(employees.this,Reaviews.class);
            startActivity(in);
            return  true;
        }

        if(id==R.id.location)
        {
            Intent in=new Intent(Intent.ACTION_VIEW);
            Uri uri=Uri.parse("geo:0,0?q=it sharks");
            in.setData(uri);
            startActivity(in);
            return  true;
        }

        if(id==R.id.contact)
        {
            Intent in =new Intent(employees.this,Contacts.class);
            startActivity(in);
            return  true;
        }
        return super.onOptionsItemSelected(item);
    }
}
