package fci.aliahmed.gradiuationprogect;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
//adapter for instructor list view
public class instructors_adapter extends BaseAdapter
{
    //definition of variables
    int []instructorImage;
    String []instructorName;
    String []courseName;
    Activity activity;

    //constructor
    public instructors_adapter (int [] image,String[]instructor_name,String [] course_name,Activity activity)
    {
        this.instructorImage=image;
        this.instructorName=instructor_name;
        this.courseName=course_name;
        this.activity=activity;
    }

    //function to return the number of elements
    @Override
    public int getCount() {
        return instructorName.length;
    }

    //function to return the item position
    @Override
    public Object getItem(int position) {
        return null;
    }

    //function to return the id of the item
    @Override
    public long getItemId(int position) {
        return 0;
    }

    //function to connect the list view desgin class and code class
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater=activity.getLayoutInflater();
        View view=inflater.inflate(R.layout.list_of_instructors, null);
        ImageView inst_image=(ImageView)view.findViewById(R.id.inst_image);
        TextView inst_name=(TextView)view.findViewById(R.id.inst_name);
        TextView coursename=(TextView)view.findViewById(R.id.cours_inst);
        inst_image.setImageResource(instructorImage[position]);
        inst_name.setText(instructorName[position]);
        coursename.setText(courseName[position]);
        return  view;
    }
}
