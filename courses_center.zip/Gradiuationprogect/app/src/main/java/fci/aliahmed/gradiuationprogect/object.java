package fci.aliahmed.gradiuationprogect;


public class object
{
    //definition of the variable used in this screen
    int image;
    String name,content,hours,weeks;

    //constructor
    public object (int image,String name,String content,String hours,String weeks)
    {
        this.image=image;
        this.name=name;
        this.content=content;
        this.hours=hours;
        this.weeks=weeks;
    }


    //function to get course image
    public int get_image()
    {
        return this.image;
    }

    //function to get course name
    public  String get_name()
    {
        return this.name;
    }

    //function to get course content
    public String get_content()
    {
        return this.content;
    }

    //function to get course hours
    public String get_hours()
    {
        return this.hours;
    }

    //function to get course weeks
    public String get_weeks()
    {
        return this.weeks;
    }

}

