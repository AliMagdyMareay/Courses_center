package fci.aliahmed.gradiuationprogect;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class review_class extends Fragment
{
    @Nullable
    @Override

    //function to call the fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
       View view=inflater.inflate(R.layout.review_fragment,null);

        //definition and casting the views
        final EditText reviewerName=(EditText)view.findViewById(R.id.viewr_name);
        final EditText courseReviwed=(EditText)view.findViewById(R.id.course_name_review);
        final EditText reviewText=(EditText)view.findViewById(R.id.review);
        Button add_review=(Button)view.findViewById(R.id.add);

        //function to set the button to make an action
        add_review.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                //variables to store the content of the edit texts
                final String user_name=reviewerName.getText().toString();
                final String course_name=courseReviwed.getText().toString();
                final String review_text=reviewText.getText().toString();

                //request to use the volley function
                //volley function is used to receive or share the file the include the data
                RequestQueue queue= Volley.newRequestQueue(getActivity());
                StringRequest request =new StringRequest(Request.Method.POST,
                        //the ip address of the json file
                        "http://192.168.1.6/review.php?f=save"
                        , new Response.Listener<String>() {
                    @Override
                    //check that the connection is done
                    public void onResponse(String response)
                    {
                        try
                        {
                            Log.d("Done",response);

                            JSONObject object=new JSONObject(response);
                            String my_respnd= object.getString("response");

                            if(my_respnd.equalsIgnoreCase("Done"))
                            {
                                if(user_name.equals("")||course_name.equals("")||review_text.equals(""))
                                {
                                    Toast.makeText(getActivity(), "please enter all required data", Toast.LENGTH_SHORT).show();
                                }
                                else
                                Toast.makeText(getActivity(), "Adding review done", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (JSONException e)
                        {
                            e.printStackTrace();
                        }
                    }
                }
                        , new Response.ErrorListener()
                {
                    //function to handel the exception of internet connection failing
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Log.d("error", error.getMessage());
                        if(user_name.equals("")||course_name.equals("")||review_text.equals(""))
                        {
                            Toast.makeText(getActivity(), "please enter all required data", Toast.LENGTH_SHORT).show();
                        }
                        else
                        Toast.makeText(getActivity(),"No internet connection",Toast.LENGTH_SHORT).show();
                    }

                })

                {
                    //function that create json file to share with database bey key and value
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError
                    {
                        Map<String,String>params=new HashMap<String, String>();
                        params.put("username",user_name);
                        params.put("course_name",course_name);
                        params.put("review",review_text);
                        return params;
                    }
                };
                queue.add(request);
                reviewerName.setText("");
                courseReviwed.setText("");
                reviewText.setText("");
            }
        });
        return view;
    }
}