package fci.aliahmed.gradiuationprogect;



public class review_object
{
    //definition of the variable used in this screen
    String reviewerName,courseReviewed,reviewText;

    //constructor
    public review_object(String name,String course_name,String review)
    {
        this.reviewerName=name;
        this.courseReviewed=course_name;
        this.reviewText=review;
    }

    //function to get the name of reviewer
    public  String get_name()
    {
        return this.reviewerName;
    }

    //function to get the course or instructor reviewed
    public String get_course()
    {
        return this.courseReviewed;
    }

    //function to get the review text
    public String get_review()
    {
        return this.reviewText;
    }

}
