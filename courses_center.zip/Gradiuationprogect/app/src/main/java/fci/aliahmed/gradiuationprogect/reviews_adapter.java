package fci.aliahmed.gradiuationprogect;


import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//adapter for reviews list view
public class reviews_adapter extends BaseAdapter
{
    //definition of variables
    Activity activity;
    ArrayList <review_object> reviews=new ArrayList<>();

    //constructor
    public reviews_adapter(ArrayList <review_object> reviews,Activity activity)
    {
        this.reviews=reviews;
        this.activity=activity;
    }

    //function to return the number of elements
    @Override
    public int getCount() {
        return reviews.size();
    }

    //function to return the item position
    @Override
    public Object getItem(int position) {
        return null;
    }

    //function to return the id of the item
    @Override
    public long getItemId(int position) {
        return 0;
    }

    //function to connect the list view desgin class and code class
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater=activity.getLayoutInflater();
        View view=inflater.inflate(R.layout.view_review_adapter, null);
        TextView reviewername=(TextView)view.findViewById(R.id.review_name);
        TextView reviewedCourse=(TextView)view.findViewById(R.id.course);
        TextView reviewDescription=(TextView)view.findViewById(R.id.review_discription);
        reviewername.setText(reviews.get(position).get_name());
        reviewedCourse.setText(reviews.get(position).get_course());
        reviewDescription.setText(reviews.get(position).get_review());
        return view;
    }
}
