package fci.aliahmed.gradiuationprogect;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
//this class to create the database (sqlite)
public class sql_database extends SQLiteOpenHelper
{
    //define the database name and version
    final static String database_name="ITSharks_database";
    final static int database_version=1;

    //define the courses table column
    final static String table_courses="courses";
    final static String course_id="id";
    final static String course_name="name";
    final static String course_image="image";
    final static String course_hours="hours";
    final static String course_weeks="weeks";
    final static String course_content="content";

    //constructor
    public sql_database(Context context)
    {
        super(context,database_name , null, database_version);
    }

    @Override
    //main function to call the database class
    public void onCreate(SQLiteDatabase db)
    {
        //create the table
        String creat_course_table=
                "CREATE TABLE " + table_courses + " ("+course_id + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        course_name + " TEXT UNIQUE NOT NULL, "+
                        course_hours + " TEXT NOT NULL, "+
                        course_content + " TEXT, "+
                        course_image + " INTEGER NOT NULL, "+
                        course_weeks + " TEXT NOT NULL "+");";

        db.execSQL(creat_course_table);

        //setting the data of all courses in the center
        int []images=new int[]{R.drawable.android,R.drawable.java,R.drawable.asp,R.drawable.oracle,R.drawable.c};
        String []name=new String[]{"android","java","c#/Asp.net","oracle","c/c++"};
        String[] hours=new String[]{"92 Hours","104 Hours","100 Hours","114 Hours","40 Hours"};
        String []weeks=new String[]{"8 Weeks","9 Weeks","9 Weeks","10 Weeks","4 Weeks"};
        String [] content=new String[]{"android coutse \n"+
                "JAVA\n" +
                "Java What's Java ?\n" +
                "Java history.\n" +
                "Java Bytecode.\n" +
                "Java virtual machine.\n" +
                "JRE(Java runtime environment ).\n" +
                "JDK (Java Development kit ).\n" +
                "SDK(Software Development Kit ).\n" +
                "API(Application Programming Interfaces ).\n" +
                "Variables Data Types.\n" +
                "Strings.\n" +
                "Input-output.\n" +
                "Comments.\n" +
                "Math Operations.\n" +
                "Conditional statement (if- switch).\n" +
                "Looping.\n" +
                "Exceptions.\n" +
                "Streams (input stream- output stream).\n" +
                "Casting.\n" +
                "OOP\n" +
                "\n" +
                "Class.\n" +
                "Object Member.\n" +
                "Variable Member.\n" +
                "method.\n" +
                "Constructor.\n" +
                "Access Control Modifiers.\n" +
                "Inheritance.\n" +
                "Polymorphism.\n" +
                "Interfaces.\n" +
                "Abstraction.Introduction to Android\n" +
                "\n" +
                "android \n"+
                "What’s Android.\n" +
                "Why Android.\n" +
                "Android Market.\n" +
                "Android Versions.\n" +
                " Android Architecture\n" +
                "\n" +
                "Android Stack.\n" +
                "Android Features.\n" +
                "Android Architecture layer.\n" +
                " Tools\n" +
                "\n" +
                "SDK (software development kit ).\n" +
                "JDK (java development kit ).\n" +
                "IDE (integrated development environment.\n" +
                " Android Studio\n" +
                "\n" +
                "Setup Android Studio.\n" +
                "Android Manifest.\n" +
                "Important Folders.\n" +
                "Important Buttons.\n" +
                "LogCat.\n" +
                "Emulator  and genymotion.\n" +
                "Android Components\n" +
                "\n" +
                "Activities.\n" +
                "Services.\n" +
                "Broadcast Receivers.\n" +
                "Content Providers.\n" +
                " Building Application UI\n" +
                "\n" +
                "Material design concept.\n" +
                "Layouts.\n" +
                "Layout types.\n" +
                "View class.\n" +
                "Attributes.\n" +
                " Activities\n" +
                "\n" +
                "Life Cycle.\n" +
                "Call Back.\n" +
                "Methods Interacting with UI.\n" +
                "Resources.\n" +
                " Intents\n" +
                "\n" +
                "Explicit Intents.\n" +
                "Implicit Intent.\n" +
                "Intent Filter.\n" +
                "listView\n" +
                "\n" +
                "Adapter.\n" +
                "Listview.\n" +
                "CustomListView.\n" +
                "Networking\n" +
                "\n" +
                "Threads.\n" +
                "AsyncTask.\n" +
                "Volley library.\n" +
                "JSON Parsing.\n" +
                "Data Storing\n" +
                "\n" +
                "Shared preferences.\n" +
                "Internal storage.\n" +
                "External storage.\n" +
                "SQLite.\n" +
                "Services\n" +
                "\n" +
                "Overview of services in Android.\n" +
                "Implementing a Service.\n" +
                "a Service lifecycle.\n" +
                "Fragments\n" +
                "\n" +
                "Static.\n" +
                "Dynamic.\n" +
                "Android Fragments Tabs.\n" +
                "Camera\n" +
                "\n" +
                "Working with camera.\n" +
                "Multimedia in Android\n" +
                "\n" +
                "Simple Media Player APP.\n" +
                "Simple video playback.\n" +
                "Menus\n" +
                "\n" +
                "Context Menu.\n" +
                "Popup Menu.\n" +
                "Option Menus.\n" +
                "Notifications\n" +
                "\n" +
                "Notification properties.\n" +
                "Attach Actions to notification.\n" +
                "Pending Intent.\n" +
                "Maps and Locations\n" +
                "\n" +
                "Working with Google Maps.\n" +
                "Finding current location and listening for changes in location.\n" +
                "Working with GPS."
                ,"Java course \n"+
                "Introduction And Overview \n" +
                "\n" +
                "introduction to stand-alone application\n" +
                "overview about JDK,JVM,JRE\n" +
                "How to compile code into bytecode\n" +
                "overview about IDE\n" +
                "overview about libraries\n" +
                "Declaring and initializing variables\n" +
                "Datatypes\n" +
                "How to print in Console\n" +
                "How to scan values from user\n" +
                " Control Structure \n" +
                "\n" +
                "If, if-else statements\n" +
                "While loop\n" +
                "Do while loop\n" +
                "For & foreach loop\n" +
                "Switch statement\n" +
                "Introduction to  Dialogs and message boxes.\n" +
                " Arrays \n" +
                "\n" +
                "Arrays\n" +
                "String\n" +
                "OOP \n" +
                "\n" +
                "Overview about traditional programming,\n" +
                "Access Modifiers,\n" +
                "Introduction to classes and methods,\n" +
                "Introduction to object oriented programming\n" +
                "Encapsulation\n" +
                "Inheritance\n" +
                "Polymorphism\n" +
                "Abstraction\n" +
                "Interfaces\n" +
                "GUI \n" +
                "\n" +
                "Introduction to Graphics User Interface,\n" +
                "How to use components(Swing UI)\n" +
                " SQL \n" +
                "\n" +
                "Introduction to SQL,\n" +
                "Submitting SQL statements,\n" +
                "Retrieving and processing results.\n" +
                "JDBC \n" +
                "\n" +
                "Introduction to JDBC,\n" +
                "Choosing database drivers,\n" +
                " Connecting to a database.\n" +
                "Application Using JDBC \n" +
                "\n" +
                "Implementing application using JDBC\n" +
                "Storing And Retrieving Data With File I/O\n" +
                "\n" +
                "Reading and writing files.\n" +
                "Creating, deleting and renaming files.\n" +
                "Obtaining directory and file information.\n" +
                "Exception Handling And Threads\n" +
                "\n" +
                "Handling exceptions with try and catch.\n" +
                "Threads.\n" +
                "Project \n" +
                "\n" +
                "Project In windows Form \n" +
                "Group of 2-3 persons select an idea.\n" +
                "The lecturer discusses the code with you."
                ,"Introduction and Principles \n" +
                "\n" +
                "C# course \n"+
                "Introduction\n" +
                "Reading and writing to a console\n" +
                "Built-in data types\n" +
                "String data type\n" +
                "Control Structure \n" +
                "\n" +
                "Operators\n" +
                "Nullable Types\n" +
                "Datatype conversions\n" +
                "Comments\n" +
                "If statement\n" +
                "Switch statement\n" +
                "While loop\n" +
                "Do while loop\n" +
                "For & foreach loop\n" +
                " Functions, Arrays\n" +
                "\n" +
                "arrays(one & two dimension).\n" +
                "Methods.\n" +
                "Method parameters.\n" +
                "passing array to function.\n" +
                " Classes \n" +
                "\n" +
                "Class - Introduction\n" +
                "Static & Instance members\n" +
                "Method hiding \n" +
                "Structs\n" +
                "Classes Vs Structs\n" +
                " OOP\n" +
                "\n" +
                "Encapsulations\n" +
                "Polymorphism\n" +
                "Method overriding Vs hiding\n" +
                "Method overloading. \n" +
                "Inheritance.\n" +
                "Diamond Problem\n" +
                "Multiple inheritance \n" +
                "Classes Properties \n" +
                "\n" +
                "Interfaces\n" +
                "Explicit interface implementation\n" +
                "Abstract Classes\n" +
                "Abstract Classes Vs Interfaces\n" +
                " Delegates, Exception Handling \n" +
                "\n" +
                "Delegates\n" +
                "Multicast Delegates\n" +
                "Exception Handling\n" +
                "Inner Exceptions\n" +
                "Custom Exceptions\n" +
                "Exception Handling Abuse\n" +
                "Preventing Exception Handling Abuse\n" +
                "Enums, Modifiers, Reflection\n" +
                "\n" +
                "Enums\n" +
                "Enums Concepts\n" +
                "Types vs Type Members\n" +
                "Access Modifiers - Private, Public and Protected\n" +
                "Access Modifiers - Internal and Protected Internal\n" +
                "Access Modifiers for types ,Attributes\n" +
                "Reflection\n" +
                "Late binding using reflection\n" +
                " Generics\n" +
                "\n" +
                "Generic Collections\n" +
                "Difference between Convert.ToString() and ToString() method\n" +
                "Difference between string and stringbuilder\n" +
                "Dictionary, list, Lambada\n" +
                "\n" +
                "dictionary\n" +
                "List collection class \n" +
                "When to use a dictionary over list\n" +
                "Anonymous methods\n" +
                "Lambda expression\n" +
                " ADO\n" +
                "\n" +
                "What is ADO.NET\n" +
                "SQLConnection object in ADO.NET\n" +
                "Storing and retrieving connection\n" +
                "SqlCommand in ado.net\n" +
                "Calling a stored procedure with output parameters\n" +
                "SqlDataReader object in ADO.NET\n" +
                "SqlDataReader object's NextResult() method\n" +
                "SqlDataAdapter in ADO.NET\n" +
                " Project \n" +
                "\n" +
                "Project In windows Form \n" +
                "Group of 2-3 persons select an idea.\n" +
                "The lecturer discusses the code with you."
                ,"oracle \n"+
                "Introduction and Overview Control Structure\n" +
                "Datatypes\n" +
                "If, if-else statements\n" +
                "While loop\n" +
                "Do while loop\n" +
                "For & foreach loop\n" +
                "Arrays\n" +
                "Arrays\n" +
                "String\n" +
                "OOP\n" +
                "Overview about traditional programming,\n" +
                "Access Modifiers,\n" +
                "Introduction to classes and methods,\n" +
                "Introduction to object oriented programming\n" +
                "Encapsulation\n" +
                "Inheritance\n" +
                "Polymorphism\n" +
                "Abstraction\n" +
                "Interfaces\n" +
                "Introduction to servlet\n" +
                "Introduction to Application Server\n" +
                "Servlet life cycle methods\n" +
                "Accessing servlet environment variables\n" +
                "Adding text fields and drop-down lists\n" +
                "Retrieving form data in the servlet\n" +
                "Accessing Databases with Servelets\n" +
                "Connecting to the database.\n" +
                "Submitting SQL statements\n" +
                "Retrieving and processing data\n" +
                "Data Manipulation Language\n" +
                "DML Statements\n" +
                "The SELECT Statement\n" +
                "The INSERT Statement\n" +
                "The DELETE Statement\n" +
                "The UPDATE Statement\n" +
                "More SQL*Plus Commands\n" +
                "SQL FUNCTIONS\n" +
                "Introduction\n" +
                "The DISTINCT Keyword\n" +
                "Aliases\n" +
                "Miscellaneous Functions\n" +
                "Mathematical Functions\n" +
                "String Functions\n" +
                "Date Functions\n" +
                "Conversion Functions\n" +
                "Pseudo Columns\n" +
                "Groups\n" +
                "SQL Statements\n" +
                "GROUP BY Clause\n" +
                "HAVING Clause\n" +
                "Order of a SELECT Statement\n" +
                "SQL Operators\n" +
                "Simple Selects\n" +
                "Comparison Operators\n" +
                "IN and NOT IN Operators\n" +
                "BETWEEN Operator\n" +
                "The LIKE Operator\n" +
                "Logical Operators\n" +
                "IS NULL and IS NOT NULL\n" +
                "ANY\n" +
                "ALL\n" +
                "Joining Tables\n" +
                "Joins\n" +
                "Cartesian Product\n" +
                "Inner Joins\n" +
                "Equi-Join\n" +
                "Table Aliases\n" +
                "Non-Equi Join\n" +
                "Non-Key Join\n" +
                "Reflexive Join\n" +
                "Natural Join\n" +
                "Outer Joins\n" +
                "Right Outer Join\n" +
                "Left Outer Join\n" +
                "Full Outer Join\n" +
                "Oracle-Specific Syntax for Outer Joins\n" +
                "Data Definition Language\n" +
                "Categories of SQL Statements\n" +
                "Oracle Datatypes\n" +
                "The CREATE Statement\n" +
                "The DROP Command\n" +
                "The ALTER Command\n" +
                "Integrity Constraints\n" +
                "Entity Integrity Constraints\n" +
                "Referential Integrity Constraints\n" +
                "Modifying Table to Use Constraints\n" +
                "Checking Constraints\n" +
                "The Data Dictionary"
                ,"c++ course \n"+
                "Introduction and Principles \n" +
                "What is programming language?\n" +
                "How the programs run?\n" +
                "Output functions.\n" +
                "Variables and Data types.\n" +
                "Read value from user and process it.\n" +
                "Mathematical basics.\n" +
                "Control Structure \n" +
                "Sequence Control structure.\n" +
                "Selection Control Structures.\n" +
                "If-else.\n" +
                "Dangling-else Problem\n" +
                "Repetition (Loops) \n" +
                "For, while, do-while.\n" +
                "Counter-Controlled Repetition.\n" +
                "Sentinel-Controlled Repetition.\n" +
                "Break and continue Statements.\n" +
                "Nested Control Statements.\n" +
                "Workshop 1:\n" +
                "Implementing ATM System\n" +
                "Functions \n" +
                "Function Prototypes, built in functions and user defined functions.\n" +
                "References and Reference Parameters, Scope Rules.\n" +
                "Function overloading, and Function Templates.\n" +
                "Inline Functions and recursive functions.\n" +
                "Math Library Functions.\n" +
                "Arrays\n" +
                "Introduction to arrays.\n" +
                "Passing arrays to functions.\n" +
                "Searching Arrays with Linear Search.\n" +
                "2-D arrays.\n" +
                "Multidimensional arrays. \n" +
                "Workshop 2:\n" +
                "Implementing XO game\n" +
                "Pointers\n" +
                "Call by reference, Call by value, and const member functions.\n" +
                "Pointer Variable Declarations and Initialization.\n" +
                "Pointer Operators.\n" +
                "Passing Arguments to Functions by Reference with Pointers.\n" +
                "Relationship between Pointers and Arrays.\n" +
                "Pointer-Based String Processing.\n" +
                "Advanced Topics (Search, Sort ...)\n" +
                "Bubble sort function.\n" +
                "Bubble sort using array.\n" +
                "Pointer to functions.\n" +
                "Linear search.\n" +
                "Binary search.\n" +
                "Search by recursion.\n" +
                "Structures, Union and Enumeration\n" +
                "Define struct.\n" +
                "Use structs with functions.\n" +
                "Union\n" +
                "Enumeration\n" +
                "Workshop 3:\n" +
                "Implementing Pharmacy system\n" +
                "Files Streaming\n" +
                "Files and Streams.\n" +
                "Creating a Sequential File, Create, read and update file.\n" +
                "Random-Access Files.\n" +
                "Writing Data Randomly to a Random-Access File.\n" +
                "Memory Allocation and Bitwise Operators\n" +
                "Dynamic Memory allocation.\n" +
                "Bitwise Operators.\n" +
                "Function with dynamic numbers of arguments\n" +
                "Workshop 4: Project \n" +
                "Group of 2-3 persons select an idea.\n" +
                "The lecturer discusses the code with you."};

        ContentValues values= new ContentValues();

        values.put(sql_database.course_name,name[0]);
        values.put(sql_database.course_hours,hours[0]);
        values.put(sql_database.course_weeks,weeks[0]);
        values.put(sql_database.course_content,content[0]);
        values.put(sql_database.course_image,images[0]);
        long temp=db.insert(sql_database.table_courses,null,values);
        Log.d("temp", temp + "");


        values.put(sql_database.course_name,name[1]);
        values.put(sql_database.course_hours,hours[1]);
        values.put(sql_database.course_weeks,weeks[1]);
        values.put(sql_database.course_content,content[1]);
        values.put(sql_database.course_image,images[1]);
        long temp1=db.insert(sql_database.table_courses,null,values);
        Log.d("temp1", temp1 + "");


        values.put(sql_database.course_name,name[2]);
        values.put(sql_database.course_hours,hours[2]);
        values.put(sql_database.course_weeks,weeks[2]);
        values.put(sql_database.course_content,content[2]);
        values.put(sql_database.course_image,images[2]);
        long temp2=db.insert(sql_database.table_courses,null,values);
        Log.d("temp2", temp2 + "");


        values.put(sql_database.course_name,name[3]);
        values.put(sql_database.course_hours,hours[3]);
        values.put(sql_database.course_weeks,weeks[3]);
        values.put(sql_database.course_content,content[3]);
        values.put(sql_database.course_image,images[3]);
        long temp3=db.insert(sql_database.table_courses,null,values);
        Log.d("temp3", temp3 + "");



        values.put(sql_database.course_name,name[4]);
        values.put(sql_database.course_hours,hours[4]);
        values.put(sql_database.course_weeks,weeks[4]);
        values.put(sql_database.course_content,content[4]);
        values.put(sql_database.course_image,images[4]);
        long temp4=db.insert(sql_database.table_courses,null,values);
        Log.d("temp4", temp4 + "");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }
}
