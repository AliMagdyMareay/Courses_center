package fci.aliahmed.gradiuationprogect;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class start extends AppCompatActivity
{
    //definition of the variable used in this screen
    ImageView logoImage;

    //the main function
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        //handler is used to make a splash screen the appear in the beginning of using the app every time
        new android.os.Handler().postDelayed(new Runnable() {
            @Override
            public void run()
            {
            //intent to move from this screen to the home screen
                Intent in = new Intent(start.this, cources.class);
                startActivity(in);
                finish();
            }
        }, 3000);

        logoImage=(ImageView)findViewById(R.id.logo);
        logoImage.setImageResource(R.drawable.logo);

    }
}
