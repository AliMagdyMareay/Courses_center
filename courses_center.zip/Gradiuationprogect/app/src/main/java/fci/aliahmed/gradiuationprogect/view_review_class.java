package fci.aliahmed.gradiuationprogect;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class view_review_class extends Fragment
{
    //definition of the variable used in this screen
    ListView reviewsListview;
    ArrayList<review_object> Myobject = new ArrayList<>();

    reviews_adapter adapter;
    @Nullable
    @Override

    //function to call the fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.view_reviews_fragment, null);
        reviewsListview = (ListView) view.findViewById(R.id.reviews_list);

        //request to use the volley function
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        StringRequest request = new StringRequest(Request.Method.GET,
                //the ip address of the json file
                "http://192.168.1.6/review.php?f=show",
                new Response.Listener<String>()
        {
            //check that the connection is done
            @Override
            public void onResponse(String response) {
                try {
                    Log.d("Test", response);
                    JSONObject object=new JSONObject(response);
                    JSONArray response2 = object.getJSONArray("list");
                    for (int i = 0; i < response2.length(); i++) {
                        JSONObject object1 = response2.getJSONObject(i);
                        String name = object1.getString("Name");
                        String course_name = object1.getString("Course");
                        String review_txt = object1.getString("Review_text");
                        Myobject.add(new review_object(name, course_name, review_txt));
                    }
                    //setting the reviews to the list view
                    adapter = new reviews_adapter(Myobject,getActivity());
                    reviewsListview.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            //function to handel the exception of internet connection failing
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("error", error.getMessage());
                Toast.makeText(getActivity(), "No internet connection", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(request);

    return view ;
   }
}
